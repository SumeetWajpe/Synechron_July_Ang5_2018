import { Component } from '@angular/core';
import {CourseService} from './course.service';

@Component({
    selector: 'new-course',
    template:` <div style="width:400px;border:2px solid red;border-radius:10px;padding:20px;margin:20px">
    <h1> Course Service Consumer </h1>
    <input type="text" [(ngModel)]="theInputCourse" />    
    <input type="button" value="Add>>"
    (click)="AddCourse()"   />
    <input type="button" value="Get Random Course!"
    (click)="GetRandomCourse()" />
    {{thereceivedCourse}}`   ,
    // providers:[CourseService]
  })
export class NewCourseComponent{
    theInputCourse:string="";
    thereceivedCourse:string="";
        constructor(public servObj:CourseService){
             console.log(this.servObj.getRandomCourse());
        }

        GetRandomCourse(){
           this.thereceivedCourse =  this.servObj.getRandomCourse();
        }

        AddCourse(){
                this.servObj.addNewCourse(this.theInputCourse);
        }
}