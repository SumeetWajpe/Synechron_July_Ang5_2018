
import {Component,Input} from '@angular/core'
import { Product } from './product.model';


@Component({
selector:`product`,
template:`
<div [ngClass]="{'ProductStyle':true,'BackGroundStyle':false}">
<h2> {{prodDetails.name | uppercase | lowercase}} </h2>
<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>      
<b> Price :  </b> {{prodDetails.price | currency:'INR':true}} 
<br/>
 <b> Quantity :  </b> {{prodDetails.quantity | qty:'nos'  }} <br/>                
  <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'  }} <br/>              
  <b> RAW Data : </b> {{ prodDetails | json }}
</div>
`,styles:[`
.ProductStyle{
    border: 2px solid red;
  border-radius: 20px;
  padding:10px;
  margin:10px;
  }
  .BackGroundStyle{
    background-color:lightblue;
  }
  
  `]
})
export class ProductComponent{
     @Input()   prodDetails=new Product(); 
     classToBeApplied:string='ProductStyle';
}