import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'

import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { NewCourseComponent } from './newcourse.component';
import { CourseService } from './course.service';

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent,ShoppingCartComponent,ProductComponent,
    CourseComponent,QuantityPipe,NewCourseComponent ],
  bootstrap:    [ AppComponent ],
  providers:[CourseService]
})
export class AppModule { }
