import { Component } from '@angular/core';
import {Course} from './course.model';

@Component({
  selector: 'my-app',
  template:`<shoppingcart></shoppingcart>`
  // template: `
  // <div *ngFor="let c of listOfCourses">
  //     <course [details]="c"></course>
  // </div>
  // <course></course>
  // `,
})
export class AppComponent  { name = 'Angular'; 
      //  listOfCourses:string[] = ['React','Angular','Node']
      // listOfCourses:Course[] = [        
      //   new Course('React','3 Days','https://sabe.io/tutorials/getting-started-with-react/hero.png')   ,
      //   new Course('Node','3 Days')   ,
      //   new Course('Redux','2 Days')   
      // ]

}
