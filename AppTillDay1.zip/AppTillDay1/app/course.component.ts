import { Component, Input } from "@angular/core";
import { Course } from "./course.model";

@Component({
        selector:`course`,  
        template:`
       <h1> {{coursedetails.name}} </h1>

       <img src="{{coursedetails.imageUrl}}" height="200px" width="200px" /><br/>
       <img [src]="coursedetails.imageUrl" height="200px" width="200px" /><br/>


       <b> Duration : </b> {{coursedetails.duration}} <br/>
        `})
export class CourseComponent{
     @Input('details')   coursedetails:Course=new Course();
}