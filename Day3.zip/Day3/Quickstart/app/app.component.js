"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'Angular';
        //  listOfCourses:string[] = ['React','Angular','Node']
        // listOfCourses:Course[] = [        
        //   new Course('React','3 Days','https://sabe.io/tutorials/getting-started-with-react/hero.png')   ,
        //   new Course('Node','3 Days')   ,
        //   new Course('Redux','2 Days')   
        // ]
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n <h1> Using Routing ! </h1>\n\n <a class=\"btn btn-primary\" routerLink=\"/posts\"> Posts </a>\n <a class=\"btn btn-primary\" routerLink=\"/cart\"> ShoppingCart </a>\n\n\n\n  <router-outlet></router-outlet>"
        // template:`<posts></posts>`
        // template:`<new-course></new-course>
        // <new-course></new-course>`
        // template:`<shoppingcart></shoppingcart>`
        // template: `
        // <div *ngFor="let c of listOfCourses">
        //     <course [details]="c"></course>
        // </div>
        // <course></course>
        // `,
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map