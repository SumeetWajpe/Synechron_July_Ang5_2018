"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CourseService = (function () {
    function CourseService() {
        this.courses = ['React', 'Node', 'Redux'];
    }
    CourseService.prototype.getAllCourses = function () {
        return this.courses;
    };
    CourseService.prototype.addNewCourse = function (newCourse) {
        this.courses.push(newCourse);
    };
    CourseService.prototype.getRandomCourse = function () {
        return this.courses[Math.floor(Math.random() * this.courses.length)];
    };
    return CourseService;
}());
exports.CourseService = CourseService;
//# sourceMappingURL=course.service.js.map