import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import {HttpModule} from '@angular/http';
import {Routes,RouterModule} from '@angular/router'


import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { NewCourseComponent } from './newcourse.component';
import { CourseService } from './course.service';
import { PostsComponent } from './posts.component';
import { PostDetailsComponent } from './post.details.component';

const routes:Routes = [
    {path:'cart',component:ShoppingCartComponent},
    {path:'posts',component:PostsComponent},
    {path:'post/:id',component:PostDetailsComponent},

    {path:'',redirectTo:'/cart',pathMatch:'full'},
    {path:'**',redirectTo:'/posts'}
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,ShoppingCartComponent,ProductComponent,
    CourseComponent,QuantityPipe,
    NewCourseComponent,PostsComponent,PostDetailsComponent ],
  bootstrap:    [ AppComponent ],
  providers:[CourseService]
})
export class AppModule { }
