export class Course{
    
    constructor(public name:string="Angular",public duration:string="3 Days",public imageUrl:string="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png"){
        
    }
}