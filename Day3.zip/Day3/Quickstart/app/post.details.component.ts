import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector:`post-detail`,  
    template:`
    <h1> Post Details for {{postId}} </h1>
     `
})
export class PostDetailsComponent {
    postId:number;
            constructor(private currRoute:ActivatedRoute){
            }
            ngOnInit(){
                    this.currRoute.params.subscribe(
                        p => this.postId = p["id"]
                    )
            }
    }