"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = (function () {
    function Product(name, price, quantity, rating, ImageUrl) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.rating = rating;
        this.ImageUrl = ImageUrl;
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=product.model.js.map