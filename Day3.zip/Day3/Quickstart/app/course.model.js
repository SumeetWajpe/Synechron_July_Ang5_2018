"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = (function () {
    function Course(name, duration, imageUrl) {
        if (name === void 0) { name = "Angular"; }
        if (duration === void 0) { duration = "3 Days"; }
        if (imageUrl === void 0) { imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png"; }
        this.name = name;
        this.duration = duration;
        this.imageUrl = imageUrl;
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.model.js.map