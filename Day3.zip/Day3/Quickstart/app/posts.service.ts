import {Http} from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{

    constructor(private httpObj:Http){

    }

    //Observable<Post[]> with Post as Model
    // getPosts():Observable<any>{
    //     // ajaxified request !
    // return    this.httpObj.get('https://jsonplaceholder.typicode.com/posts').map(r => r.json())
    // }

    // Using Promise
    getPosts(){
        // ajaxified request !
    return    this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    }
}