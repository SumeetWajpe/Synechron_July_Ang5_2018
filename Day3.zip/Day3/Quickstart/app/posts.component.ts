import { Component, Input, OnInit } from "@angular/core";
import { PostsService } from "./posts.service";

@Component({
    selector:`posts`,  
    template:`
    <h1> All Posts </h1>
    <ul>
            <li *ngFor="let p of allPosts">
            
        <a routerLink="/post/{{p.id}}">    {{p.title}}  </a>
            
            </li>
    </ul>    `,
providers:[PostsService]
})
export class PostsComponent implements OnInit{
    allPosts:any=[];

    // Observables
    //     constructor(private servObj:PostsService){
    //        var ObColl=  this.servObj.getPosts();
    //        ObColl.subscribe((response)=>{
    //            //console.log('Within Component !')
    //         this.allPosts = response;
    // })
    //     }

    // Promises
    constructor(private servObj:PostsService){
        
     }

     ngOnInit(){
       let aPromise =     this.servObj.getPosts(); // returns a promise
        aPromise.then(
                    (response)=>{
                        this.allPosts = response.json();
                        },
                        (err)=>{
                                console.log(err)
                        }
        ); // eof then
     }// eof ngOnInit()
    
    }