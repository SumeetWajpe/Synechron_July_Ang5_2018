export class CourseService{
    public courses:string[] = ['React','Node','Redux'];

    getAllCourses():string[]{
            return this.courses;
    }
    addNewCourse(newCourse:string){
        this.courses.push(newCourse);
    }
    getRandomCourse():string{
            return this.courses[Math.floor(Math.random() * this.courses.length )]
    }
}